/*
* ECC Signer Tool
*
* Copyright 2020 José Antonio Jiménez Campos (@RavenSystem)
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include <wolfssl/options.h>
#include <wolfssl/ssl.h>
#include <wolfssl/wolfcrypt/types.h>
#include <wolfssl/wolfcrypt/logging.h>
#include <wolfssl/wolfcrypt/sha512.h>
#include <wolfssl/wolfcrypt/ecc.h>
#include <wolfssl/wolfcrypt/asn_public.h>

#define ARGC                4
#define HASHSIZE            48
#define SIGNSIZE            104

int main(int argc, char* argv[]) {
    FILE *file, *private_key_file, *public_key_file;
    FILE *hash_file, *sign_file;
    ecc_key private_key, public_key;
    Sha384 sha;
    byte *file_buffer, *private_key_file_buffer, *public_key_file_buffer, *hash;
    size_t sz;
    word32 idx = 0;
    int i, ret = 0;
    
    printf("\nECC SIGNER TOOL\n");
    printf("(c) 2020 José A. Jiménez Campos\n\n");
    
    if (argc != ARGC) {
        printf("Usage:\n   %s <file_to_sign> <private_key.der> <public_key.der>\n\n", argv[0]);
        return -100;
    }
    
    // Load file to sign
    file = fopen(argv[1], "rb");
    if (!file) {
        printf("! File to sign not found\n");
        return -1;
    }
    printf("File to sign: %s\n", argv[1]);
    
    fseek(file, 0L, SEEK_END);
    int file_size = ftell(file);
    fseek(file, 0L, SEEK_SET);
    
    printf("File size: %i\n\n", file_size);
    file_buffer = malloc(file_size * sizeof(byte));
    fread(file_buffer, 1, file_size, file);
    fclose(file);
    
    // Load Private Key
    private_key_file = fopen(argv[2], "rb");
    if (!private_key_file) {
        printf("! Private key file not found\n");
        return -2;
    }
    printf("Private ECC Key file: %s\n", argv[2]);
    
    fseek(private_key_file, 0L, SEEK_END);
    int private_key_file_size = ftell(private_key_file);
    fseek(private_key_file, 0L, SEEK_SET);
    
    printf("Private Key size: %i\n", private_key_file_size);
    private_key_file_buffer = malloc(private_key_file_size * sizeof(byte));
    fread(private_key_file_buffer, 1, private_key_file_size, private_key_file);
    fclose(private_key_file);
    
    wc_ecc_init(&private_key);
    ret = wc_EccPrivateKeyDecode(private_key_file_buffer, &idx, &private_key, (word32) private_key_file_size);
    printf("Loading private key: %s (%i)\n\n", ret == 0 ? "OK" : "FAIL", ret);
    
    // Load Public Key
    public_key_file = fopen(argv[3], "rb");
    if (!public_key_file) {
        printf("! Public key file not found\n");
        return -3;
    }
    printf("Public ECC Key file: %s\n", argv[3]);
    
    fseek(public_key_file, 0L, SEEK_END);
    int public_key_file_size = ftell(public_key_file);
    fseek(public_key_file, 0L, SEEK_SET);
    
    printf("Public Key size: %i\n", public_key_file_size);
    public_key_file_buffer = malloc(public_key_file_size * sizeof(byte));
    fread(public_key_file_buffer, 1, public_key_file_size, public_key_file);
    fclose(public_key_file);
    idx = 0;
    wc_ecc_init(&public_key);
    ret = wc_EccPublicKeyDecode(public_key_file_buffer, &idx, &public_key, (word32) public_key_file_size);
    printf("Loading public key: %s (%i)\n\n", ret == 0 ? "OK" : "FAIL", ret);
    
    // Create hash SHA384
    wc_InitSha384(&sha);
    wc_Sha384Update(&sha, file_buffer, file_size);
    hash = malloc(HASHSIZE);
    ret = wc_Sha384Final(&sha, hash);
    printf("Hash result: %s (%i)\n", ret == 0 ? "OK" : "FAIL", ret);
    
    hash_file = fopen("hash", "w");
    if (!hash_file) {
        printf("Error creating hash file\n");
        return -4;
    }
    
    sz = fwrite(hash, 1, HASHSIZE, hash_file);
    fclose(hash_file);
    
    printf("Saved to file: hash\n");
    
    printf("Hash:\n");
    for (i = 0; i<HASHSIZE; i++) {
        printf("%hhx", hash[i]);
    }
    printf("\n\n");
    
    // Create Signature using Private Key
    unsigned int sign_len = SIGNSIZE;
    byte sign[SIGNSIZE];
    WC_RNG rng;
    wc_InitRng(&rng);
//     wc_RNG_GenerateBlock(&rng, hash, HASHSIZE);
    ret = wc_ecc_sign_hash(hash, HASHSIZE, sign, &sign_len, &rng, &private_key);
    printf("Sign result: %s (%i)\n", ret == 0 ? "OK" : "FAIL", ret);
    
    sign_file = fopen("sign", "w");
    if (!sign_file) {
        printf("Error creating sign file\n");
        return -5;
    }
    sz = fwrite(sign, 1, SIGNSIZE, sign_file);
    fclose(sign_file);
    
    printf("Saved to file: sign\n");
    
    printf("Signature:\n");
    for (int i = 0; i<SIGNSIZE; i++) {
        printf("%hhx", sign[i]);
    }
    printf("\n\n");
    
    // Verify Signature using Public Key
    int verify_result;
    wc_ecc_verify_hash(sign, sign_len, hash, HASHSIZE, &verify_result, &public_key);
    
    printf("Sign verification: %s (%i)\n\n", verify_result ? "OK" : "FAIL", verify_result);
}
