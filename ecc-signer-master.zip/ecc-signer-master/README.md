# ECC Signer Command Line Tool

This command line tool is used to create a hash SHA384 of a binary file and its ECC signature.

Requirements:

* WolfSSL:
Download it and save in the same directory of ecc-signer.
https://github.com/wolfSSL/wolfssl/releases

Compile WolfSSL with:
```
cd wolfssl-*-stable
./autogen.sh
./configure --disable-shared --enable-eccencrypt --enable-ecccustcurves --enable-hkdf --prefix=../wolfssl
make
make install
cd ..
```

Compile ecc_signer:
```
./compile.sh
```

Use ecc_signer:
```
./ecc_signer <file_to_sign> <private_key.der> <public_key.der>
```
