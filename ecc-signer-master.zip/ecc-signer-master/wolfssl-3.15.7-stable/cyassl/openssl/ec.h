/* ec.h for openssl */

#include <wolfssl/openssl/ec.h>
